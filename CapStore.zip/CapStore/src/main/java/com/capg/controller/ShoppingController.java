package com.capg.controller;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capg.service.InventoryUpdateService;

@RestController
public class ShoppingController {
	@Autowired
	InventoryUpdateService shoppingService;
	
	@RequestMapping(value = "/shopping/inventoryupdate/{prodId}/{ordId}",method=RequestMethod.PUT)
    public String inventoryupdate(@PathVariable String prodId,@PathVariable String ordId)
    {
        return shoppingService.inventoryupdate(prodId, ordId);
    }
	
}
