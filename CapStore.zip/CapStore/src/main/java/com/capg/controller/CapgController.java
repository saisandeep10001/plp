package com.capg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capg.bean.Customer;
import com.capg.bean.Merchant;
import com.capg.bean.WishItem;
//import com.capg.service.CapgService;
import com.capg.service.CapgService;

@RestController
public class CapgController {

	@Autowired CapgService capgService;
	
	@PostMapping("/register/customer/{password}")
	public void registerCustomer(@RequestBody Customer customer, @PathVariable("password") String pass) {
		capgService.registerCustomer(customer,pass);
	}
	@PostMapping("/addWish/{custId}")
	public void addCustomerWish(@PathVariable String custId,@RequestBody WishItem wish) {
		capgService.addCustomerWish(custId,wish);
	}
	@PostMapping("/register/merchant/{password}")
	public void registerMerchant(@RequestBody Merchant merchant,@PathVariable("password") String pass) {
		capgService.registerMerchant(merchant,pass);
	}
	
	@RequestMapping("/login/customer/{email}/{password}")
	public Customer loginCustomerByEmail(@PathVariable String email, @PathVariable String password) {
		return capgService.loginCustomer(email, password);
	}
	
	@RequestMapping("/login/merchant/{email}/{password}")
	public Merchant loginMerchantByEmail(@PathVariable String email, @PathVariable String password) {
		return capgService.loginMerchant(email, password);
	}

}
