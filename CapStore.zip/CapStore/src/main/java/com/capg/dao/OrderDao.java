package com.capg.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.capg.bean.OrderedItem;

public interface OrderDao extends JpaRepository<OrderedItem, String> {
	@Query("from OrderedItem where ordId=:ordId and ordStatus='REC'")
	OrderedItem getOrderedById(@Param("ordId") String ordId);



}
