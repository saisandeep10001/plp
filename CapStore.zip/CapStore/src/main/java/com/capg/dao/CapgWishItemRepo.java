package com.capg.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capg.bean.WishItem;

public interface CapgWishItemRepo extends JpaRepository<WishItem, String>{

}
