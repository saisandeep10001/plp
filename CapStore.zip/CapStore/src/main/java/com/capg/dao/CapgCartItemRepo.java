package com.capg.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capg.bean.CartItem;

public interface CapgCartItemRepo extends JpaRepository<CartItem, String> {

}
