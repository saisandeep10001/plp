package com.capg.service;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.capg.bean.OrderedItem;
import com.capg.bean.Product;
import com.capg.dao.OrderDao;
import com.capg.dao.ProductDao;
@Service
public class InventoryUpdateServiceImpl implements InventoryUpdateService {
	@Autowired
	ProductDao productDao;
	@Autowired
	OrderDao orderDao;
	@Override
	public String inventoryupdate(String prodId, String ordId){
		try {
			Product temp1 = productDao.getOne(prodId);
			
			OrderedItem temp2 = orderDao.getOrderedById(ordId);
//			System.out.println(temp2);
            int currentQuantity = temp1.getQty();
            
            int orderedQuantity = temp2.getOrdQty();
            
            if(currentQuantity >= 1 && currentQuantity >= orderedQuantity) 
            {
            	
            int updatedQuantity = currentQuantity-orderedQuantity;
            temp1.setQty(updatedQuantity);
           
            productDao.save(temp1);
            }
            else 
            {
            	 return "currently unavailable";
            }
		}catch(NullPointerException e) {
			return "failed";
		}
            return "updated";
	}
}
