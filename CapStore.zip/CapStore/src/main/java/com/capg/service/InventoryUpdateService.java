package com.capg.service;


public interface InventoryUpdateService {
	public String inventoryupdate(String prodId,String ordId);
}
